import mysql.connector as mariadb
import datetime

class DbConnection():

    def __init__(self, user, password):
        self.m_conn=None
        try:
            self.m_conn=mariadb.connect(user=user, password=password, database='applicators')
            self.cursor=self.m_conn.cursor()
        except mariadb.DatabaseError:
            print("Wrong username or password")


    def writeToDb(self, applicator,crosssection,
                  crimp_hight, crimp_width,
                  isocrimp_higth, isocrimp_width,
                  pull_force, foto_link1, foto_link2, foto_link3,user):
        date=datetime.datetime.now()
        #TODO check diff between (%s)%word and (%s),(word)
        self.cursor.execute("""INSERT INTO data (applicator, crosssection,
                             crimp_height, crimp_width,
                             isocrimp_height, isocrimp_width,
                             pull_force, foto1, foto2, foto3, date,user)
                             VALUES ('%s',%s,%s,%s, %s,%s,%s,'%s','%s','%s','%s','%s')
                            """ % (applicator,crosssection,
                                   crimp_hight, crimp_width,
                                   isocrimp_higth, isocrimp_width,
                                   pull_force, foto_link1,foto_link2,foto_link3 ,date,user))
        self.m_conn.commit()

    def checkUsers(self,user):
        self.cursor.execute("SELECT * FROM users WHERE user='%s'"%(user))
        row=self.cursor.fetchall()

        return row[0][1]

    def updateNominal(self,applicator,crosssection,
                        crimp_height_plus, crimp_height_nominal, crimp_height_minus,
                        crimp_width_plus, crimp_width_nominal, crimp_width_minus,
                        isocrimp_height_plus, isocrimp_height_nominal, isocrimp_height_minus,
                        isocrimp_width_plus, isocrimp_width_nominal, isocrimp_width_minus,
                        pull_force,user):
        self.cursor.execute("""UPDATE nominal
                             SET applicator='%s',
                             crosssection=%s,
                             crimp_height_plus=%s,
                             crimp_height_nominal=%s,
                             crimp_height_minus=%s,
                             crimp_width_plus=%s,
                             crimp_width_nominal=%s,
                             crimp_width_minus=%s,
                             isocrimp_height_plus=%s,
                             isocrimp_height_nominal=%s,
                             isocrimp_height_minus=%s,
                             isocrimp_width_plus=%s,
                             isocrimp_width_nominal=%s,
                             isocrimp_width_minus=%s,
                             pull_force=%s,
                             user='%s'
                             WHERE applicator='%s'
                             """%(applicator,
                             crosssection,
                             crimp_height_plus,crimp_height_nominal, crimp_height_minus,
                             crimp_width_plus,crimp_width_nominal, crimp_width_minus,
                             isocrimp_height_plus,isocrimp_height_nominal, isocrimp_height_minus,
                             isocrimp_width_plus,isocrimp_width_nominal, isocrimp_width_minus,
                             pull_force,user,applicator))



    def getApplicatorsList(self):
        self.cursor.execute("SELECT applicator FROM nominal")
        applicators=self.cursor.fetchall()
        applicatorsList=[]
        for i in applicators:
            applicatorsList.append(i[0])
        return applicatorsList

    def writeToNominal(self,applicator,
                             crosssection,
                             crimp_height_plus,crimp_height_nominal, crimp_height_minus,
                             crimp_width_plus,crimp_width_nominal, crimp_width_minus,
                             isocrimp_height_plus,isocrimp_height_nominal, isocrimp_height_minus,
                             isocrimp_width_plus,isocrimp_width_nominal, isocrimp_width_minus,
                             pull_force,user):
        self.cursor.execute("""INSERT INTO nominal
                            (applicator,
                             crosssection,
                             crimp_height_plus,crimp_height_nominal, crimp_height_minus,
                             crimp_width_plus,crimp_width_nominal, crimp_width_minus,
                             isocrimp_height_plus,isocrimp_height_nominal, isocrimp_height_minus,
                             isocrimp_width_plus,isocrimp_width_nominal, isocrimp_width_minus,
                             pull_force,user)
                             VALUES
                             ('%s',%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,'%s')
                             """%(applicator,
                             crosssection,
                             crimp_height_plus,crimp_height_nominal, crimp_height_minus,
                             crimp_width_plus,crimp_width_nominal, crimp_width_minus,
                             isocrimp_height_plus,isocrimp_height_nominal, isocrimp_height_minus,
                             isocrimp_width_plus,isocrimp_width_nominal, isocrimp_width_minus,
                             pull_force,user))
        self.m_conn.commit()

    def getApplicatorData(self,applicator):
        self.cursor.execute("SELECT * FROM nominal WHERE applicator='%s'"%applicator)
        data=self.cursor.fetchall()
        return data[0]

    def getHistory(self):
        self.cursor.execute("SELECT * FROM data")
        data=self.cursor.fetchall()
        return data

    def getRecord(self,applicator,date):
        self.cursor.execute("SELECT * FROM data WHERE applicator='%s' AND date='%s'"%(applicator,date))
        record=self.cursor.fetchall()
        return record[0]

    def createTable(self):
        self.cursor.execute("""CREATE TABLE nominal (applicator VARCHAR(20) NOT NULL,
                             crosssection REAL NOT NULL,
                             crimp_height_plus REAL NOT NULL,
                             crimp_height_nominal REAL NOT NULL,
                             crimp_height_minus REAL NOT NULL,
                             crimp_width_plus REAL NOT NULL,
                             crimp_width_nominal REAL NOT NULL,
                             crimp_width_minus REAL NOT NULL,
                             isocrimp_height_plus REAL NOT NULL,
                             isocrimp_height_nominal REAL NOT NULL,
                             isocrimp_height_minus REAL NOT NULL,
                             isocrimp_width_plus REAL NOT NULL,
                             isocrimp_width_nominal REAL NOT NULL,
                             isocrimp_width_minus REAL NOT NULL,
                             pull_force REAL NOT NULL)""")
        self.m_conn.commit()

    def closeConn(self):
        self.m_conn.close()

