from PyQt5.QtWidgets import QWidget, QLineEdit, QPushButton, QLabel
from PyQt5.QtGui import QFont
import dbConnection

class AutorizWidget(QWidget):
    def __init__(self,parent=None):
        super(AutorizWidget, self).__init__(parent)

        self.loginField=QLineEdit(self)
        self.loginField.move(370,270)

        self.passwdField=QLineEdit(self)
        self.passwdField.move(370,330)
        self.passwdField.setEchoMode(QLineEdit.Password)

        self.stateLabel=QLabel('Input login and password',self)
        self.stateLabel.setStyleSheet('color : red')
        font = QFont("Times", 15, QFont.Bold)
        self.stateLabel.setFont(font)
        self.stateLabel.setFixedWidth(400)
        self.stateLabel.move(328,230)

        self.loginButton=QPushButton('Login',self)
        self.loginButton.move(395,380)
        self.loginButton.pressed.connect(self.login)

    def login(self):
        user=self.loginField.text()
        password=self.passwdField.text()
        if password == '':
            self.stateLabel.setText("Input password!")
        elif user=='':
            self.stateLabel.setText("Input login!")
        else:
            self.parent().connection = dbConnection.DbConnection(user, password)
            if self.parent().connection.m_conn != None:
                self.parent().login=user
                self.loginField.setText('')
                self.passwdField.setText('')
                self.stateLabel.setText("")
                userGroup=self.parent().connection.checkUsers(user)
                if userGroup=='admin':
                    self.parent().currentLayout.setCurrentIndex(1)
                elif userGroup=="user":
                    self.parent().currentLayout.setCurrentIndex(2)
            else:
                self.stateLabel.setText("Wrong username or password!")


