from PyQt5.QtWidgets import QWidget, QPushButton, QLabel,QListWidget
from PyQt5.QtGui import QFont
from PyQt5.QtGui import QPixmap
import PyQt5
import dbConnection

class GetDbData(QWidget):
    def __init__(self,parent=None):
        super(GetDbData, self).__init__(parent)

        self.dataList=QListWidget(self)
        self.dataList.setFixedSize(250,600)
        data=self.parent().connection.getHistory()
        font = QFont("Times", 10, QFont.Bold)
        i=0
        for row in data:
            self.dataList.addItem(str(row[0])+'     '+str(row[10]))
            self.dataList.item(i).setFont(font)
            i+=1
        self.dataList.itemDoubleClicked.connect(self.itemSelected)

        self.labelList=[]

        applicator_Label=QLabel('Applicator',self)
        self.labelList.append(applicator_Label)
        crosssection_Label=QLabel('Crosssection',self)
        self.labelList.append(crosssection_Label)
        crimp_height_Label=QLabel("Crimp height",self)
        self.labelList.append(crimp_height_Label)
        crimp_width_Label=QLabel("Crimp width",self)
        self.labelList.append(crimp_width_Label)
        isocrimp_height_Label=QLabel('isoCrimp height',self)
        self.labelList.append(isocrimp_height_Label)
        isocrimp_width_Label=QLabel('isoCrimp width',self)
        self.labelList.append(isocrimp_width_Label)
        pull_force_Label=QLabel("Pullforce",self)
        self.labelList.append(pull_force_Label)
        foto1_path_Label=QLabel("Path to foto 1",self)
        self.labelList.append(foto1_path_Label)
        foto2_path_Label = QLabel("Path to foto 2", self)
        self.labelList.append(foto2_path_Label)
        foto3_path_Label = QLabel("Path to foto 3", self)
        self.labelList.append(foto3_path_Label)
        date_Label=QLabel("Date",self)
        self.labelList.append(date_Label)
        user_Label=QLabel("Tehnical support ",self)
        self.labelList.append(user_Label)

        self.FotoList=[]
        foto1=QLabel(self)
        self.FotoList.append(foto1)
        foto2 = QLabel(self)
        self.FotoList.append(foto2)
        foto3 = QLabel(self)
        self.FotoList.append(foto3)
        y=5
        for label in self.FotoList:
            label.setFixedSize(100,100)
            label.move(600,y)
            y+=110

        y=10
        for label in self.labelList:
            label.setFixedWidth(600)
            label.move(270,y)
            y+=50


        self.backButton = QPushButton("Previous menu", self)
        self.backButton.move(800, 5)
        self.backButton.pressed.connect(self.backButtonPressed)


    def itemSelected(self,item):
        self.leaveDefaulLabelsValue()
        splited_item=item.text().split(" ",1)
        record=self.parent().connection.getRecord(splited_item[0],splited_item[1])
        for i in range(len(record)):
            self.labelList[i].setText(self.labelList[i].text()+" = "+str(record[i]))
            if i>=7 and i<=9:
                pixmap = QPixmap()
                pixmap.load(str(record[i]))
                pixmap = pixmap.scaled(self.FotoList[i-7].size(), PyQt5.QtCore.Qt.KeepAspectRatio)
                self.FotoList[i-7].setPixmap(pixmap)


    def backButtonPressed(self):
        self.leaveDefaulLabelsValue()
        self.parent().currentLayout.setCurrentIndex(1)

    def leaveDefaulLabelsValue(self):
        pixmap=QPixmap()
        for label in self.labelList:
            text=label.text().split(" =")
            label.setText(text[0])
        for label in self.FotoList:
            label.setPixmap(pixmap)