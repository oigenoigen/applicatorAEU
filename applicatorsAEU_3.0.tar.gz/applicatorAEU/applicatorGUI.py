import sys
from PyQt5.QtWidgets import QWidget, QStackedLayout, QApplication, QMainWindow
from PyQt5.QtCore import QRect
from autorizWidget import AutorizWidget
from chooseWidget import ChooseWidget
from entryDataWidget import EntryDataWidget
from getDbWidget import GetDbData
from writeToNomWidget import WriteToNomWidget
from createApplicatorWidget import CreateApplicatorWidget
import dbConnection


class MainWindow(QWidget):
    def __init__(self):
        super(MainWindow, self).__init__()
        self.connection = dbConnection.DbConnection('reader', 'Cv123456')
        self.login = None
        self.setFocus()
        self.currentLayout=QStackedLayout()

        self.setFixedSize(900,600)

        autorizWidget=AutorizWidget(parent=self)
        self.currentLayout.addWidget(autorizWidget)#index 0

        chooseWidget = ChooseWidget(parent=self)
        self.currentLayout.addWidget(chooseWidget)  # index 1

        entryWidget=EntryDataWidget(parent=self)
        self.currentLayout.addWidget(entryWidget)#index 2

        getDbData=GetDbData(parent=self)
        self.currentLayout.addWidget(getDbData)#index 3

        writeToNomWidget = WriteToNomWidget(parent=self)
        self.currentLayout.addWidget(writeToNomWidget)  # index 4

        createApplicatorWidget=CreateApplicatorWidget(parent=self)
        self.currentLayout.addWidget(createApplicatorWidget)  # index 5

        self.currentLayout.setCurrentIndex(0)
        self.setLayout(self.currentLayout)
        self.setFocus()

        self.connection.closeConn()


        self.setGeometry(300, 300, 500, 250)
        self.setWindowTitle('AEU Applicators')

        self.show()




if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = MainWindow()
    sys.exit(app.exec_())