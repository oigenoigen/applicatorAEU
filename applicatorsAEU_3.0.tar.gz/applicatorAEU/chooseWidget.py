from PyQt5.QtWidgets import QWidget, QLineEdit, QPushButton, QLabel
import dbConnection

class ChooseWidget(QWidget):
    def __init__(self,parent=None):
        super(ChooseWidget, self).__init__(parent)

        self.readButton=QPushButton("Read applicator history",self)
        self.readButton.setFixedSize(250,100)
        self.readButton.move(330,50)
        self.readButton.pressed.connect(self.readHist)


        self.writeToNomButton=QPushButton("Write to NOMINAL database",self)
        self.writeToNomButton.setFixedSize(250,100)
        self.writeToNomButton.move(330,200)
        self.writeToNomButton.pressed.connect(self.writeToNom)

        self.writeToHistButton=QPushButton("Write to applicator history database",self)
        self.writeToHistButton.setFixedSize(250,100)
        self.writeToHistButton.move(330,350)
        self.writeToHistButton.pressed.connect(self.writeToHist)

    def readHist(self):
        self.parent().currentLayout.setCurrentIndex(3)

    def writeToNom(self):
        self.parent().currentLayout.setCurrentIndex(4)

    def writeToHist(self):
        self.parent().currentLayout.setCurrentIndex(2)