from PyQt5.QtWidgets import QWidget, QLineEdit, QPushButton, QLabel, QComboBox, QFileDialog
import PyQt5
from PyQt5.QtGui import QPixmap
from PyQt5.QtGui import QFont
import dataCheck

class EntryDataWidget(QWidget):
    def __init__(self,parent=None):
        super(EntryDataWidget, self).__init__(parent)

        self.callInstance=[]
        self.correctFields=0
        self.applicatorData=[]
        self.fotoPath1=None
        self.fotoPath2 = None
        self.fotoPath3 = None

        self.backButton = QPushButton("Previous menu", self)
        self.backButton.move(800, 10)
        self.backButton.pressed.connect(self.backButtonPressed)

        #applicator

        applicatorLabel=QLabel("Applicator",self)
        applicatorLabel.move(350,12)

        self.applicatorBox=QComboBox(self)
        self.applicatorBox.move(440,10)
        applicators=self.parent().connection.getApplicatorsList()
        applicators.insert(0,"Choose")
        self.applicatorBox.addItems(applicators)
        self.applicatorBox.activated.connect(self.applicatorChoosed)


        # crosssection
        self.crosssection_Label = QLabel("Crosssection", self )
        self.crosssection_Label.setFixedWidth(200)
        self.crosssection_Label.move(350, 62)


        # crimp higth
        self.crimp_height_plus_Label = QLabel("Crimp height+", self)
        self.crimp_height_plus_Label.setFixedWidth(200)
        self.crimp_height_plus_Label.move(5, 112)

        self.crimp_height_nominal_Label = QLabel("Crimp height nominal", self)
        self.crimp_height_nominal_Label.setFixedWidth(200)
        self.crimp_height_nominal_Label.move(170, 112)

        self.crimp_height_minus_Label = QLabel("Crimp height-", self)
        self.crimp_height_minus_Label.setFixedWidth(200)
        self.crimp_height_minus_Label.move(690, 112)

        self.crimp_height_measure_Field = QLineEdit(self)
        self.crimp_height_measure_Field.move(520, 108)
        self.crimp_height_measure_Field.tol1=None
        self.crimp_height_measure_Field.tol2=None
        self.crimp_height_measure_Field.textChanged.connect(lambda :self.check(self.crimp_height_measure_Field,
                                                                               self.crimp_height_measure_Field.text(),
                                                                               self.crimp_height_measure_Field.tol1,
                                                                               self.crimp_height_measure_Field.tol2))#THIS IS FUCKING MAAAAAGIC

        crimp_height_measure_Lable = QLabel("Measurement",self)
        crimp_height_measure_Lable.move(420, 110)


        # crimp width
        self.crimp_width_plus_Label = QLabel("Crimp width+", self)
        self.crimp_width_plus_Label.setFixedWidth(200)
        self.crimp_width_plus_Label.move(5, 160)

        self.crimp_width_nominal_Label = QLabel("Crimp width nominal", self)
        self.crimp_width_nominal_Label.setFixedWidth(200)
        self.crimp_width_nominal_Label.move(170, 160)

        crimp_width_measure_Lable = QLabel("Measurement", self)
        crimp_width_measure_Lable.move(420, 162)

        self.crimp_width_minus_Label = QLabel("Crimp width-", self)
        self.crimp_width_minus_Label.setFixedWidth(200)
        self.crimp_width_minus_Label.move(690, 160)

        self.crimp_width_measure_Field = QLineEdit(self)
        self.crimp_width_measure_Field.move(520, 158)
        self.crimp_width_measure_Field.tol1 = None
        self.crimp_width_measure_Field.tol2 = None
        self.crimp_width_measure_Field.textChanged.connect(lambda: self.check(self.crimp_width_measure_Field,
                                                                               self.crimp_width_measure_Field.text(),
                                                                               self.crimp_width_measure_Field.tol1,
                                                                               self.crimp_width_measure_Field.tol2))


        # isocrimp heigth
        self.isocrimp_height_plus_Label = QLabel("isoCrimp height+", self)
        self.isocrimp_height_plus_Label.setFixedWidth(200)
        self.isocrimp_height_plus_Label.move(5, 210)

        self.isocrimp_height_nominal_Label = QLabel("isoCrimp height nominal", self)
        self.isocrimp_height_nominal_Label.setFixedWidth(200)
        self.isocrimp_height_nominal_Label.move(170, 210)

        isocrimp_height_measure_Lable = QLabel("Measurement", self)
        isocrimp_height_measure_Lable.move(420, 212)

        self.isocrimp_height_minus_Label = QLabel("isoCrimp height-", self)
        self.isocrimp_height_minus_Label.setFixedWidth(200)
        self.isocrimp_height_minus_Label.move(690, 210)

        self.isocrimp_height_measure_Field = QLineEdit(self)
        self.isocrimp_height_measure_Field.move(520, 208)
        self.isocrimp_height_measure_Field.tol1 = None
        self.isocrimp_height_measure_Field.tol2 = None
        self.isocrimp_height_measure_Field.textChanged.connect(lambda: self.check(self.isocrimp_height_measure_Field,
                                                                               self.isocrimp_height_measure_Field.text(),
                                                                               self.isocrimp_height_measure_Field.tol1,
                                                                               self.isocrimp_height_measure_Field.tol2))


        # isocrimp width
        self.isocrimp_width_plus_Label = QLabel("isoCrimp width+", self)
        self.isocrimp_width_plus_Label.setFixedWidth(200)
        self.isocrimp_width_plus_Label.move(5, 260)

        self.isocrimp_width_nominal_Label = QLabel("isoCrimp width nominal", self)
        self.isocrimp_width_nominal_Label.setFixedWidth(200)
        self.isocrimp_width_nominal_Label.move(170, 260)

        isocrimp_width_measure_Lable = QLabel("Measurement", self)
        isocrimp_width_measure_Lable.move(420, 262)

        self.isocrimp_width_minus_Label = QLabel("isoCrimp width-", self)
        self.isocrimp_width_minus_Label.setFixedWidth(200)
        self.isocrimp_width_minus_Label.move(690, 260)

        self.isocrimp_width_measure_Field = QLineEdit(self)
        self.isocrimp_width_measure_Field.move(520, 258)
        self.isocrimp_width_measure_Field.tol1 = None
        self.isocrimp_width_measure_Field.tol2 = None
        self.isocrimp_width_measure_Field.textChanged.connect(lambda: self.check(self.isocrimp_width_measure_Field,
                                                                               self.isocrimp_width_measure_Field.text(),
                                                                               self.isocrimp_width_measure_Field.tol1,
                                                                               self.isocrimp_width_measure_Field.tol2))


        # pullforce
        self.pullforce_Label = QLabel("Pullforce", self)
        self.pullforce_Label.setFixedWidth(200)
        self.pullforce_Label.move(190, 310)

        pullforce_measure_Label = QLabel("Measurement",self)
        pullforce_measure_Label.move(420, 310)

        self.pullforce_measure_Field = QLineEdit(self)
        self.pullforce_measure_Field.move(520, 308)
        self.pullforce_measure_Field.tol1 = None
        self.pullforce_measure_Field.tol2 = None
        self.pullforce_measure_Field.textChanged.connect(lambda: self.check(self.pullforce_measure_Field,
                                                                               self.pullforce_measure_Field.text(),
                                                                               self.pullforce_measure_Field.tol1,
                                                                               self.pullforce_measure_Field.tol2))

        self.notifLabel=QLabel('Choose the applicator',self)
        self.notifLabel.setStyleSheet('color : red')
        font = QFont("Times", 15, QFont.Bold)
        self.notifLabel.setFont(font)
        self.notifLabel.setFixedWidth(400)
        self.notifLabel.move(5,25)

        self.writeButton = QPushButton("Write data", self)
        self.writeButton.move(350, 490)
        self.writeButton.setFixedSize(200,80)
        self.writeButton.pressed.connect(self.writeData)

        self.Foto1=QLabel(self)
        self.Foto1.setFixedSize(120,120)
        self.Foto1.move(100,320)

        self.openFileButton1 = QPushButton("Upload foto", self)
        self.openFileButton1.move(114,440)
        self.openFileButton1.pressed.connect(self.openFoto1)

        self.Foto2 = QLabel(self)
        self.Foto2.setFixedSize(120, 120)
        self.Foto2.move(376, 320)

        self.openFileButton2 = QPushButton("Upload foto", self)
        self.openFileButton2.move(390, 440)
        self.openFileButton2.pressed.connect(self.openFoto2)

        self.Foto3 = QLabel(self)
        self.Foto3.setFixedSize(120, 120)
        self.Foto3.move(662, 320)

        self.openFileButton3 = QPushButton("Upload foto", self)
        self.openFileButton3.move(676, 440)
        self.openFileButton3.pressed.connect(self.openFoto3)


    def check(self,instance,value,tol1,tol2):
        result=dataCheck.check(value,tol1,tol2)
        if result==1:
            if instance in self.callInstance:
                self.notifLabel.setText("Fill fields according to tolerances")
            else:
                self.callInstance.append(instance)
                self.correctFields+=result
                self.notifLabel.setText("Fill fields according to tolerances")
        else:
            if value!='':
                self.notifLabel.setText("Incorrect value!")
            else:
                self.notifLabel.setText("Fill fields according to tolerances")
            if instance in self.callInstance:
                self.callInstance.remove(instance)
                self.correctFields-=1
            else:
                pass

    def openFoto1(self):#Of course, it`s nice idea to make only one function, but I have no idea, how to make it for now
        fname = QFileDialog.getOpenFileName(self, 'Open file', '/home')[0]
        pixmap=QPixmap()
        pixmap.load(fname)
        pixmap=pixmap.scaled(self.Foto1.size(),PyQt5.QtCore.Qt.KeepAspectRatio)
        self.Foto1.setPixmap(pixmap)
        self.fotoPath1=fname

    def openFoto2(self):#Of course, it`s nice idea to make only one function, but I have no idea, how to make it for now
        fname = QFileDialog.getOpenFileName(self, 'Open file', '/home')[0]
        pixmap=QPixmap()
        pixmap.load(fname)
        pixmap=pixmap.scaled(self.Foto2.size(),PyQt5.QtCore.Qt.KeepAspectRatio)
        self.Foto2.setPixmap(pixmap)
        self.fotoPath2 = fname

    def openFoto3(self):#Of course, it`s nice idea to make only one function, but I have no idea, how to make it for now
        fname = QFileDialog.getOpenFileName(self, 'Open file', '/home')[0]
        pixmap=QPixmap()
        pixmap.load(fname)
        pixmap=pixmap.scaled(self.Foto3.size(),PyQt5.QtCore.Qt.KeepAspectRatio)
        self.Foto3.setPixmap(pixmap)
        self.fotoPath3 = fname

    def writeData(self):
        if self.correctFields==5 and self.fotoPath1!=None and self.fotoPath2!=None and self.fotoPath3!=None:
            applicator=self.applicatorBox.currentText()
            crosssection=self.applicatorData[1]
            crimpHeight=float(self.crimp_height_measure_Field.text())
            crimpWidth=float(self.crimp_width_measure_Field.text())
            isocrimpHeight = float(self.isocrimp_height_measure_Field.text())
            isocrimpWidth = float(self.isocrimp_width_measure_Field.text())
            pullForce=float(self.pullforce_measure_Field.text())
            user=self.parent().login
            self.parent().connection.writeToDb(applicator,crosssection,
                                            crimpHeight, crimpWidth,
                                            isocrimpHeight, isocrimpWidth,
                                            pullForce, self.fotoPath1,self.fotoPath2,self.fotoPath3 ,user)
            self.clearFields()
            self.applicatorBox.setCurrentIndex(0)
            self.notifLabel.setText('Choose the applicator')
        elif self.fotoPath1 == None or self.fotoPath2 == None or self.fotoPath3 == None:
            self.notifLabel.setText('Choose ALL photos')
        else:
            self.notifLabel.setText("Some values are incorrect")

    def applicatorChoosed(self):
        self.clearFields()
        if self.applicatorBox.currentIndex()!= 0:
            self.notifLabel.setText("Fill fields according to tolerances")
            data=self.parent().connection.getApplicatorData(self.applicatorBox.currentText())
            self.applicatorData=data
            self.crosssection_Label.setText(self.crosssection_Label.text()+" = "+str(data[1]))

            self.crimp_height_measure_Field.tol1 = data[2]
            self.crimp_height_plus_Label.setText(
                self.crimp_height_plus_Label.text() + " = " + str(self.crimp_height_measure_Field.tol1))
            self.crimp_height_nominal_Label.setText(self.crimp_height_nominal_Label.text() + " = " + str(data[3]))
            self.crimp_height_measure_Field.tol2 = data[4]
            self.crimp_height_minus_Label.setText(
                self.crimp_height_minus_Label.text() + " = " + str(self.crimp_height_measure_Field.tol2))

            self.crimp_width_measure_Field.tol1 = data[5]
            self.crimp_width_plus_Label.setText(
                self.crimp_width_plus_Label.text() + " = " + str(self.crimp_width_measure_Field.tol1))
            self.crimp_width_nominal_Label.setText(self.crimp_width_nominal_Label.text() + " = " + str(data[6]))
            self.crimp_width_measure_Field.tol2 = data[7]
            self.crimp_width_minus_Label.setText(
                self.crimp_width_minus_Label.text() + " = " + str(self.crimp_width_measure_Field.tol2))

            self.isocrimp_height_measure_Field.tol1 = data[8]
            self.isocrimp_height_plus_Label.setText(
                self.isocrimp_height_plus_Label.text() + " = " + str(self.isocrimp_height_measure_Field.tol1))
            self.isocrimp_height_nominal_Label.setText(self.isocrimp_height_nominal_Label.text() + " = " + str(data[9]))
            self.isocrimp_height_measure_Field.tol2 = data[10]
            self.isocrimp_height_minus_Label.setText(
                self.isocrimp_height_minus_Label.text() + " = " + str(self.isocrimp_height_measure_Field.tol2))

            self.isocrimp_width_measure_Field.tol1 = data[11]
            self.isocrimp_width_plus_Label.setText(
                self.isocrimp_width_plus_Label.text() + " = " + str(self.isocrimp_width_measure_Field.tol1))
            self.isocrimp_width_nominal_Label.setText(self.isocrimp_width_nominal_Label.text() + " = " + str(data[12]))
            self.isocrimp_width_measure_Field.tol2 = data[13]
            self.isocrimp_width_minus_Label.setText(
                self.isocrimp_width_minus_Label.text() + " = " + str(self.isocrimp_width_measure_Field.tol2))

            self.pullforce_measure_Field.tol1 = data[14]
            self.pullforce_Label.setText(
                self.pullforce_Label.text() + " = " + str(self.pullforce_measure_Field.tol1))
            self.pullforce_measure_Field.tol2 = 1000#TODO maybe change it

        else:
            self.notifLabel.setText('Choose the applicator')


    def clearFields(self):
        self.Foto1.setPixmap(QPixmap())
        self.Foto2.setPixmap(QPixmap())
        self.Foto3.setPixmap(QPixmap())

        self.crosssection_Label.setText("Crosssection")
        self.crimp_height_minus_Label.setText("Crimp height-")
        self.crimp_height_plus_Label.setText("Crimp height+")
        self.crimp_height_nominal_Label.setText("Crimp height nominal")
        self.crimp_height_measure_Field.setText("")

        self.crimp_width_minus_Label.setText("Crimp width-")
        self.crimp_width_plus_Label.setText("Crimp width+")
        self.crimp_width_nominal_Label.setText("Crimp width nominal")
        self.crimp_width_measure_Field.setText("")

        self.isocrimp_height_minus_Label.setText("isoCrimp height-")
        self.isocrimp_height_plus_Label.setText("isoCrimp height+")
        self.isocrimp_height_nominal_Label.setText("isoCrimp height nominal")
        self.isocrimp_height_measure_Field.setText("")

        self.isocrimp_width_minus_Label.setText("isoCrimp width-")
        self.isocrimp_width_plus_Label.setText("isoCrimp width+")
        self.isocrimp_width_nominal_Label.setText("isoCrimp width nominal")
        self.isocrimp_width_measure_Field.setText("")

        self.pullforce_measure_Field.setText("")
        self.pullforce_Label.setText("Pullforce")

    def backButtonPressed(self):
        self.clearFields()
        self.notifLabel.setText('Choose the applicator')
        self.applicatorBox.setCurrentIndex(0)
        if self.parent().login != 'sa':#TODO change login check to group check
            self.parent().login=None
            self.parent().connection.closeConn()
            self.parent().currentLayout.setCurrentIndex(0)
        else:
            self.parent().currentLayout.setCurrentIndex(1)