from PyQt5.QtWidgets import QWidget, QLineEdit, QPushButton, QLabel, QComboBox
from PyQt5.QtGui import QFont

class WriteToNomWidget(QWidget):
    def __init__(self,parent=None):
        super(WriteToNomWidget, self).__init__(parent)

        # applicator
        applicatorNameLabel = QLabel("Applicator", self)
        applicatorNameLabel.move(350, 12)

        self.applicatorBox = QComboBox(self)
        self.applicatorBox.move(440, 10)
        applicators = self.parent().connection.getApplicatorsList()
        applicators.insert(0, "Choose")
        self.applicatorBox.addItems(applicators)
        self.applicatorBox.activated.connect(self.applicatorChoosed)

        # crosssection
        crosssection_Label = QLabel("Crosssection", self)
        crosssection_Label.move(350, 62)

        self.crosssection_Field = QLineEdit(self)
        self.crosssection_Field.move(440, 60)

        # crimp higth
        crimp_height_plus_Label = QLabel("Crimp higth+", self)
        crimp_height_plus_Label.move(5, 112)

        self.crimp_height_plus_Field = QLineEdit(self)
        self.crimp_height_plus_Field.move(110, 110)

        crimp_height_nominal_Label = QLabel("Crimp higth nominal", self)
        crimp_height_nominal_Label.move(270, 112)

        self.crimp_height_nominal_Field = QLineEdit(self)
        self.crimp_height_nominal_Field.move(420, 110)

        crimp_height_minus_Label = QLabel("Crimp higth-", self)
        crimp_height_minus_Label.move(590, 112)

        self.crimp_height_minus_Field = QLineEdit(self)
        self.crimp_height_minus_Field.move(690, 110)

        # crimp width
        crimp_width_plus_Label = QLabel("Crimp width+", self)
        crimp_width_plus_Label.move(5, 160)

        self.crimp_width_plus_Field = QLineEdit(self)
        self.crimp_width_plus_Field.move(110, 160)

        crimp_width_nominal_Label = QLabel("Crimp width nominal", self)
        crimp_width_nominal_Label.move(270, 160)

        self.crimp_width_nominal_Field = QLineEdit(self)
        self.crimp_width_nominal_Field.move(420, 160)

        crimp_width_minus_Label = QLabel("Crimp width-", self)
        crimp_width_minus_Label.move(590, 160)

        self.crimp_width_minus_Field = QLineEdit(self)
        self.crimp_width_minus_Field.move(690, 160)

        # isocrimp heigth
        isocrimp_height_plus_Label = QLabel("isoCrimp higth+", self)
        isocrimp_height_plus_Label.move(5, 210)

        self.isocrimp_height_plus_Field = QLineEdit(self)
        self.isocrimp_height_plus_Field.move(110, 210)

        isocrimp_height_nominal_Label = QLabel("isoCrimp higth nominal", self)
        isocrimp_height_nominal_Label.move(270, 210)

        self.isocrimp_height_nominal_Field = QLineEdit(self)
        self.isocrimp_height_nominal_Field.move(420, 210)

        isocrimp_height_minus_Label = QLabel("isoCrimp higth-", self)
        isocrimp_height_minus_Label.move(590, 210)

        self.isocrimp_height_minus_Field = QLineEdit(self)
        self.isocrimp_height_minus_Field.move(690, 210)

        # isocrimp width
        isocrimp_width_plus_Label = QLabel("isoCrimp width+", self)
        isocrimp_width_plus_Label.move(5, 260)

        self.isocrimp_width_plus_Field = QLineEdit(self)
        self.isocrimp_width_plus_Field.move(110, 260)

        isocrimp_width_nominal_Label = QLabel("isoCrimp width nominal", self)
        isocrimp_width_nominal_Label.move(270, 260)

        self.isocrimp_width_nominal_Field = QLineEdit(self)
        self.isocrimp_width_nominal_Field.move(420, 260)

        isocrimp_width_minus_Label = QLabel("isoCrimp width-", self)
        isocrimp_width_minus_Label.move(590, 260)

        self.isocrimp_width_minus_Field = QLineEdit(self)
        self.isocrimp_width_minus_Field.move(690, 260)

        # pullforce
        pullforce_Label = QLabel("pullforce", self)
        pullforce_Label.move(290, 310)

        self.pullforce_Field = QLineEdit(self)
        self.pullforce_Field.move(420, 310)

        self.notifLabel = QLabel(' ', self)
        self.notifLabel.setStyleSheet('color : red')
        font = QFont("Times", 15, QFont.Bold)
        self.notifLabel.setFont(font)
        self.notifLabel.setFixedWidth(400)
        self.notifLabel.move(5, 50)

        self.changeApplicatorDataButton = QPushButton("Change applicator", self)
        self.changeApplicatorDataButton.move(350, 390)
        self.changeApplicatorDataButton.setFixedSize(200, 80)
        self.changeApplicatorDataButton.pressed.connect(self.changeApplicatorData)

        self.createApplicatorButton=QPushButton('Create new applicator',self)
        self.createApplicatorButton.move(5, 10)
        self.createApplicatorButton.pressed.connect(self.createApplicator)

        self.backButton = QPushButton("Previous menu", self)
        self.backButton.move(800, 10)
        self.backButton.pressed.connect(self.backButtonPressed)

    def changeApplicatorData(self):
        if self.applicatorBox.currentIndex()!=0:

            applicator = self.applicatorBox.currentText()
            crosssection = float(self.crosssection_Field.text())

            crimp_height_plus = float(self.crimp_height_plus_Field.text())
            crimp_height_nominal = float(self.crimp_height_nominal_Field.text())
            crimp_height_minus = float(self.crimp_height_minus_Field.text())

            crimp_width_plus = float(self.crimp_width_plus_Field.text())
            crimp_width_nominal = float(self.crimp_width_nominal_Field.text())
            crimp_width_minus = float(self.crimp_width_minus_Field.text())

            isocrimp_height_plus = float(self.isocrimp_height_plus_Field.text())
            isocrimp_height_nominal = float(self.isocrimp_height_nominal_Field.text())
            isocrimp_height_minus = float(self.isocrimp_height_minus_Field.text())

            isocrimp_width_plus = float(self.isocrimp_width_plus_Field.text())
            isocrimp_width_nominal = float(self.isocrimp_width_nominal_Field.text())
            isocrimp_width_minus = float(self.isocrimp_width_minus_Field.text())

            pull_force = float(self.pullforce_Field.text())

            user=self.parent().login

            self.parent().connection.updateNominal(applicator,
                                                    crosssection,
                                                    crimp_height_plus, crimp_height_nominal, crimp_height_minus,
                                                    crimp_width_plus, crimp_width_nominal, crimp_width_minus,
                                                    isocrimp_height_plus, isocrimp_height_nominal, isocrimp_height_minus,
                                                    isocrimp_width_plus, isocrimp_width_nominal, isocrimp_width_minus,
                                                    pull_force,user)

            self.clearData()
        else:
            self.notifLabel.setText("Choose applicator!")


    def backButtonPressed(self):
        self.clearData()
        self.parent().currentLayout.setCurrentIndex(1)

    def createApplicator(self):
        self.parent().currentLayout.setCurrentIndex(5)

    def applicatorChoosed(self):


        if self.applicatorBox.currentIndex() != 0 :
            self.notifLabel.setText('')
            self.changeApplicatorDataButton.setText("Change applicator %s"%(self.applicatorBox.currentText()))
            data=self.parent().connection.getApplicatorData(self.applicatorBox.currentText())
            self.crosssection_Field.setText(str(data[1]))

            self.crimp_height_plus_Field.setText(str(data[2]))
            self.crimp_height_nominal_Field.setText(str(data[3]))
            self.crimp_height_minus_Field.setText(str(data[4]))

            self.crimp_width_plus_Field.setText(str(data[5]))
            self.crimp_width_nominal_Field.setText(str(data[6]))
            self.crimp_width_minus_Field.setText(str(data[7]))

            self.isocrimp_height_plus_Field.setText(str(data[8]))
            self.isocrimp_height_nominal_Field.setText(str(data[9]))
            self.isocrimp_height_minus_Field.setText(str(data[10]))

            self.isocrimp_width_plus_Field.setText(str(data[11]))
            self.isocrimp_width_nominal_Field.setText(str(data[12]))
            self.isocrimp_width_minus_Field.setText(str(data[13]))

            self.pullforce_Field.setText(str(data[14]))

        else:
            self.clearData()


    def clearData(self):
        self.notifLabel.setText('')
        self.applicatorBox.setCurrentIndex(0)
        self.changeApplicatorDataButton.setText("Change applicator")
        self.crosssection_Field.setText('')

        self.crimp_height_plus_Field.setText('')
        self.crimp_height_nominal_Field.setText('')
        self.crimp_height_minus_Field.setText('')

        self.crimp_width_plus_Field.setText('')
        self.crimp_width_nominal_Field.setText('')
        self.crimp_width_minus_Field.setText('')

        self.isocrimp_height_plus_Field.setText('')
        self.isocrimp_height_nominal_Field.setText('')
        self.isocrimp_height_minus_Field.setText('')

        self.isocrimp_width_plus_Field.setText('')
        self.isocrimp_width_nominal_Field.setText('')
        self.isocrimp_width_minus_Field.setText('')

        self.pullforce_Field.setText('')