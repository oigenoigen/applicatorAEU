from PyQt5.QtWidgets import QLabel

def check(str_val,tol1, tol2):
    correct=0
    if tol1!=None and tol2!=None:
        if str_val.replace(".","").isdigit():
            if float(str_val) >= tol1 and float(str_val) <= tol2:
                correct=1
            else:
                pass
        else:
            pass
    else:
        pass

    return correct